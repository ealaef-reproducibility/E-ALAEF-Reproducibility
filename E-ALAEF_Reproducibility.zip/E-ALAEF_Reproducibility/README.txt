E-ALAEF REPRODUCIBILITY INFORMATION

1. Dataset
The evaluation uses the publicly available Drebin Android malware dataset.

2. Evaluation Classes
Malware is treated as the positive class.
Benign applications are treated as the negative class.

3. Evaluation Sample Count
Total evaluated samples: 1,999.

4. Confusion Matrix
True Negative (TN): 958
False Positive (FP): 41
False Negative (FN): 30
True Positive (TP): 970

5. Metric Reconstruction
The reported Accuracy, Precision, Recall, F1-score, Specificity,
False-Positive Rate (FPR), and False-Negative Rate (FNR) are
reconstructed directly from the above confusion-matrix counts.

6. Metric Calculation Script
metric_calculation.py contains the formulas used to reconstruct
the reported classification metrics.

7. Confusion-Matrix Reconstruction Script
confusion_matrix_reconstruction.py reconstructs the 2 x 2
confusion matrix from the reported TN, FP, FN, and TP counts.

8. Evaluation Split
The original sample-level evaluation split from the experimental
run was not retained. Therefore, no new split is retrospectively assigned.

9. Sample Identifiers
Original sample-level identifiers were not retained from the
experimental run. No identifiers are fabricated or retrospectively assigned.

10. Random Seed
The random seed used in the original experimental run was not retained.
No seed value is retrospectively assigned.

11. Reproducibility Scope
The supplied scripts allow independent reconstruction of the reported
classification metrics and confusion matrix from the fixed counts
reported in the manuscript.
