# E-ALAEF Confusion-Matrix Reconstruction

import numpy as np
import matplotlib.pyplot as plt

TN = 958
FP = 41
FN = 30
TP = 970

cm = np.array([
    [TN, FP],
    [FN, TP]
])

print("E-ALAEF Confusion Matrix")
print("------------------------")
print(cm)

plt.figure(figsize=(6, 5))
plt.imshow(cm)

plt.xticks([0, 1], ["Benign", "Malware"])
plt.yticks([0, 1], ["Benign", "Malware"])

plt.xlabel("Predicted Class")
plt.ylabel("Actual Class")
plt.title("E-ALAEF Confusion Matrix")

for i in range(2):
    for j in range(2):
        plt.text(
            j, i,
            cm[i, j],
            ha="center",
            va="center",
            fontsize=14,
            fontweight="bold"
        )

plt.tight_layout()
plt.show()
