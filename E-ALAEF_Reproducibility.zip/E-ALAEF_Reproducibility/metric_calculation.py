# E-ALAEF Metric Calculation

TN = 958
FP = 41
FN = 30
TP = 970

N = TN + FP + FN + TP

accuracy = (TP + TN) / N
precision = TP / (TP + FP)
recall = TP / (TP + FN)
specificity = TN / (TN + FP)
f1_score = 2 * (precision * recall) / (precision + recall)
false_positive_rate = FP / (FP + TN)
false_negative_rate = FN / (FN + TP)

print("E-ALAEF Metric Reconstruction")
print("--------------------------------")
print(f"Total samples: {N}")
print(f"Accuracy: {accuracy * 100:.2f}%")
print(f"Precision: {precision * 100:.2f}%")
print(f"Recall: {recall * 100:.2f}%")
print(f"Specificity: {specificity * 100:.2f}%")
print(f"F1-score: {f1_score * 100:.2f}%")
print(f"False Positive Rate: {false_positive_rate * 100:.2f}%")
print(f"False Negative Rate: {false_negative_rate * 100:.2f}%")
