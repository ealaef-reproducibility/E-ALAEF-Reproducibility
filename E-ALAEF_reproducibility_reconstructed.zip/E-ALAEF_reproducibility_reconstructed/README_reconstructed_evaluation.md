# E-ALAEF Reconstructed Evaluation Subset

This package provides a **new, deterministic reconstruction** of a 1,999-sample evaluation subset from the publicly available Drebin feature-vector dataset.

## Important reproducibility note

This is **not claimed to be the original 1,999-sample split used in the historical E-ALAEF experiment**. The original sample-level split, sample identifiers, and random seed were not retained in the available project materials.

The subset is provided so that the current manuscript revision has a transparent, independently reproducible evaluation protocol rather than an undocumented sample selection.

## Dataset

Source file:
`drebin-215-dataset-5560malware-9476-benign.csv`

Source SHA-256:
`710f2c11b0cad04c36f56dd16398127feb697fd99e8efa7f75890b792fba3ad5`

The source dataset contains 15,036 applications:
- 5,560 malware (`S`)
- 9,476 benign (`B`)
- 215 feature attributes plus the class column.

## Reconstruction protocol

- Random seed: **42**
- Sampling: without replacement
- Evaluation samples: **1,999**
- Benign: **999**
- Malware: **1,000**
- Source row identifiers are 1-based row positions in the downloaded CSV.
- Each selected sample receives a stable identifier (`EALAEF-0001` ... `EALAEF-1999`).

The 999/1,000 class totals correspond to the actual-class totals implied by the reported confusion matrix:
- TN = 958
- FP = 41
- FN = 30
- TP = 970

## What this package does NOT claim

The reconstructed subset must not be described as the original test split or as reproducing the original model predictions. The original prediction file is not available. The reported confusion matrix can be independently checked with the existing metric-reconstruction script, but model-level prediction reproducibility requires the original predictions or an executable implementation of the original E-ALAEF model.

## Files

- `E-ALAEF_1999_reconstructed_evaluation_subset.csv` — 1,999 selected samples with features and labels.
- `E-ALAEF_1999_evaluation_manifest.csv` — sample IDs, source row IDs, split designation, and class labels.
- `create_reconstructed_evaluation_subset.py` — script that recreates the same subset from the source CSV using seed 42.

## Recommended manuscript wording

"Because the original sample-level evaluation split and prediction file were not retained, we provide a deterministic reconstruction protocol based on the publicly available Drebin feature-vector dataset. The reconstructed evaluation subset contains 1,999 samples (999 benign and 1,000 malware), with stable sample identifiers, source-row identifiers, and a fixed random seed (42). This reconstruction is provided for transparent protocol reproducibility and is not claimed to be the historical test split used to obtain the originally reported predictions."
