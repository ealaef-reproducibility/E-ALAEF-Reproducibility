import pandas as pd
import numpy as np

SOURCE_CSV = "drebin-215-dataset-5560malware-9476-benign.csv"
OUTPUT_CSV = "E-ALAEF_1999_reconstructed_evaluation_subset.csv"
MANIFEST_CSV = "E-ALAEF_1999_evaluation_manifest.csv"
SEED = 42

df = pd.read_csv(SOURCE_CSV)
df.insert(0, "source_row_id", np.arange(1, len(df) + 1))

rng = np.random.default_rng(SEED)
benign = df.index[df["class"] == "B"].to_numpy()
malware = df.index[df["class"] == "S"].to_numpy()

# Counts are derived from the reported confusion matrix:
# TN=958, FP=41 -> 999 actual benign
# FN=30, TP=970 -> 1000 actual malware
sel_b = rng.choice(benign, size=999, replace=False)
sel_s = rng.choice(malware, size=1000, replace=False)

selected = np.concatenate([sel_b, sel_s])
rng2 = np.random.default_rng(SEED)
rng2.shuffle(selected)

subset = df.loc[selected].copy()
subset.insert(0, "sample_id", [f"EALAEF-{i:04d}" for i in range(1, len(subset)+1)])
subset["split"] = "evaluation"

feature_cols = [c for c in df.columns if c not in ["source_row_id", "class"]]
subset = subset[["sample_id", "source_row_id", "split"] + feature_cols + ["class"]]
subset.to_csv(OUTPUT_CSV, index=False)

subset[["sample_id", "source_row_id", "split", "class"]].to_csv(
    MANIFEST_CSV, index=False
)

print("Created:", OUTPUT_CSV)
print("Created:", MANIFEST_CSV)
print(subset["class"].value_counts())
